"use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import Sidebar from "./Sidebar";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const supabase = useMemo(() => supabaseBrowser(), []);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    async function load() {
      const { data } = await supabase.auth.getUser();
      if (!data.user) { router.push("/login"); return; }
      setEmail(data.user.email ?? "");
      const res = await fetch("/api/me", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: data.user.id }),
      });
      const out = await res.json();
      setRole(out.profile?.role ?? "");
      setReady(true);
    }
    load();
  }, [router, supabase]);

  if (!ready) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#F4F6FB" }}>
      <div className="text-center">
        <div className="w-10 h-10 rounded-full mx-auto mb-3 animate-pulse" style={{ background: "#F5A623" }} />
        <p className="text-sm text-gray-500">Loading...</p>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen" style={{ background: "#F4F6FB" }}>
      <Sidebar email={email} role={role} />
      <main className="flex-1 ml-64 min-h-screen">
        {typeof children === "function"
          ? (children as (role: string) => React.ReactNode)(role)
          : children}
      </main>
    </div>
  );
}