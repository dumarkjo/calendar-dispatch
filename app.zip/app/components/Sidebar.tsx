"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { useMemo } from "react";

const BASE_NAV = [
  { href: "/dashboard", label: "Dashboard", icon: "⊞" },
  { href: "/dispatches", label: "Dispatches", icon: "📋" },
  { href: "/calendar", label: "Calendar", icon: "📅" },
];

const SCHEDULER_ONLY = [
  { href: "/dispatch/new", label: "New Dispatch", icon: "＋" },
  { href: "/admin", label: "Admin Panel", icon: "🛡️" },
];

export default function Sidebar({ email, role }: { email: string; role: string }) {
  const pathname = usePathname();
  const router = useRouter();
  const supabase = useMemo(() => supabaseBrowser(), []);

  const isScheduler = role === "scheduler" || role === "admin";
  const NAV = isScheduler ? [...BASE_NAV, ...SCHEDULER_ONLY] : BASE_NAV;

  async function logout() {
    await supabase.auth.signOut();
    router.push("/login");
  }

  return (
    <aside className="fixed top-0 left-0 h-screen w-64 flex flex-col z-40"
      style={{ background: "linear-gradient(180deg, #0F1A4A 0%, #1B2A6B 100%)" }}>

      {/* Logo area */}
      <div className="px-6 py-5 border-b" style={{ borderColor: "rgba(245,166,35,0.3)" }}>
        <div className="flex items-center gap-3">
          <img src="/amtec-logo.png" alt="AMTEC Logo" className="w-10 h-10 object-contain" />
          <div>
            <p className="text-white font-bold text-sm leading-tight">AMTEC</p>
            <p className="text-xs leading-tight" style={{ color: "#F5A623" }}>Dispatch Scheduler</p>
          </div>
        </div>
      </div>

      {/* Nav links */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {NAV.map(({ href, label, icon }) => {
          const active = pathname === href || pathname.startsWith(href + "/");
          return (
            <Link key={href} href={href}
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all"
              style={{
                background: active ? "rgba(245,166,35,0.2)" : "transparent",
                color: active ? "#F5A623" : "rgba(255,255,255,0.7)",
                borderLeft: active ? "3px solid #F5A623" : "3px solid transparent",
              }}>
              <span className="text-base">{icon}</span>
              {label}
            </Link>
          );
        })}
      </nav>

      {/* Role badge */}
      <div className="px-4 pb-2">
        <span className="inline-block px-2 py-0.5 rounded text-xs font-semibold uppercase tracking-wide"
          style={{ background: "rgba(245,166,35,0.15)", color: "#F5A623" }}>
          {role || "staff"}
        </span>
      </div>

      {/* User info + logout */}
      <div className="px-4 py-4 border-t" style={{ borderColor: "rgba(245,166,35,0.3)" }}>
        <div className="mb-3 px-2">
          <p className="text-xs font-semibold truncate" style={{ color: "#F5A623" }}>{email}</p>
        </div>
        <button onClick={logout}
          className="w-full text-sm py-2 px-3 rounded-lg font-medium transition-all text-left"
          style={{ background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.7)" }}>
          → Logout
        </button>
      </div>
    </aside>
  );
}