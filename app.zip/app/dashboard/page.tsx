"use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import AppLayout from "../components/AppLayout";
import Link from "next/link";

type Dispatch = {
  id: string;
  dispatch_number: string | null;
  company_name: string | null;
  date_from: string | null;
  date_to: string | null;
  transport_mode: string | null;
  created_at: string;
  type: string;
  location: string;
};

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["January","February","March","April","May","June",
  "July","August","September","October","November","December"];

const TRANSPORT_LABELS: Record<string, string> = {
  public_conveyance: "Public Conveyance",
  test_applicant_vehicle: "Test Applicant Vehicle",
  college_vehicle: "College Vehicle",
  other: "Other",
};

// ─── Computed status ──────────────────────────────────────────────────────────
type DispatchStatus = "Scheduled" | "Ongoing" | "Completed" | "Unknown";

function parseLocalDate(str: string) {
  const [y, m, d] = str.split("-").map(Number);
  return new Date(y, m - 1, d);
}

function getDispatchStatus(date_from: string | null, date_to: string | null): DispatchStatus {
  if (!date_from || !date_to) return "Unknown";
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const from = parseLocalDate(date_from);
  const to = parseLocalDate(date_to);
  if (today < from) return "Scheduled";
  if (today > to) return "Completed";
  return "Ongoing";
}

const STATUS_STYLES: Record<DispatchStatus, { bg: string; color: string }> = {
  Scheduled: { bg: "#EEF1FB", color: "#1B2A6B" },
  Ongoing:   { bg: "#DBEAFE", color: "#1E40AF" },
  Completed: { bg: "#D1FAE5", color: "#065F46" },
  Unknown:   { bg: "#F3F4F6", color: "#6B7280" },
};

function StatusBadge({ date_from, date_to }: { date_from: string | null; date_to: string | null }) {
  const status = getDispatchStatus(date_from, date_to);
  const s = STATUS_STYLES[status];
  return (
    <span className="px-2 py-0.5 rounded-full text-xs font-semibold"
      style={{ background: s.bg, color: s.color }}>
      {status}
    </span>
  );
}

function toKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
}

export default function DashboardPage() {
  const router = useRouter();
  const supabase = useMemo(() => supabaseBrowser(), []);

  const [email, setEmail] = useState("");
  const [role, setRole] = useState("");
  const [dispatches, setDispatches] = useState<Dispatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [current, setCurrent] = useState(() => new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [noAssignments, setNoAssignments] = useState(false);

  useEffect(() => {
    async function load() {
      const { data } = await supabase.auth.getUser();
      if (!data.user) { router.push("/login"); return; }
      setEmail(data.user.email ?? "");

      const meRes = await fetch("/api/me", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: data.user.id }),
      });
      const meData = await meRes.json();
      setRole(meData.profile?.role ?? "");

      const { data: session } = await supabase.auth.getSession();
      const token = session.session?.access_token;
      if (token) {
        const res = await fetch("/api/dispatches", {
          headers: { Authorization: `Bearer ${token}` },
        });
        const json = await res.json();
        setDispatches(json.dispatches ?? []);
        if (json.noAssignments) setNoAssignments(true);
      }
      setLoading(false);
    }
    load();
  }, [router, supabase]);

  const dispatchMap = useMemo(() => {
    const map: Record<string, Dispatch[]> = {};
    for (const d of dispatches) {
      if (!d.date_from || !d.date_to) continue;
      const from = parseLocalDate(d.date_from);
      const to = parseLocalDate(d.date_to);
      const cur = new Date(from);
      while (cur <= to) {
        const key = toKey(cur);
        if (!map[key]) map[key] = [];
        map[key].push(d);
        cur.setDate(cur.getDate() + 1);
      }
    }
    return map;
  }, [dispatches]);

  function getMonthDays() {
    const year = current.getFullYear();
    const month = current.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const days: (Date | null)[] = [];
    for (let i = 0; i < firstDay; i++) days.push(null);
    for (let i = 1; i <= daysInMonth; i++) days.push(new Date(year, month, i));
    return days;
  }

  const todayKey = toKey(new Date());
  const selectedDispatches = selectedDate ? (dispatchMap[selectedDate] ?? []) : [];
  const isScheduler = role === "scheduler";

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#F4F6FB" }}>
      <div className="w-8 h-8 rounded-full animate-pulse" style={{ background: "#F5A623" }} />
    </div>
  );

  return (
    <AppLayout>
      <div className="p-8">

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest mb-1" style={{ color: "#F5A623" }}>
              Dashboard
            </p>
            <h1 className="text-2xl font-black text-gray-900">
              Welcome back, {email ? email.split("@")[0] : ""}
            </h1>
            <p className="text-sm text-gray-500 mt-0.5 capitalize">Role: {role || "—"}</p>
          </div>
          {isScheduler && (
            <Link href="/dispatch/new"
              className="px-5 py-2.5 rounded-lg text-sm font-bold transition-all hover:opacity-90"
              style={{ background: "#1B2A6B", color: "white" }}>
              + New Dispatch
            </Link>
          )}
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Total Dispatches", value: dispatches.length,                                                                          color: "#1B2A6B" },
            { label: "Scheduled",        value: dispatches.filter(d => getDispatchStatus(d.date_from, d.date_to) === "Scheduled").length,  color: "#1B2A6B" },
            { label: "Ongoing",          value: dispatches.filter(d => getDispatchStatus(d.date_from, d.date_to) === "Ongoing").length,    color: "#1E40AF" },
            { label: "Completed",        value: dispatches.filter(d => getDispatchStatus(d.date_from, d.date_to) === "Completed").length,  color: "#065F46" },
          ].map(s => (
            <div key={s.label} className="bg-white rounded-xl border border-gray-200 shadow-sm px-5 py-4">
              <p className="text-2xl font-black" style={{ color: s.color }}>{s.value}</p>
              <p className="text-xs text-gray-500 font-medium mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>

        {/* No assignments banner */}
        {noAssignments && (
          <div className="mb-6 px-4 py-3 rounded-lg text-sm font-medium"
            style={{ background: "#FEF3C7", color: "#92400E", border: "1px solid #F5A623" }}>
            ⚠ No dispatches have been assigned to you yet. Please contact your scheduler.
          </div>
        )}

        {/* Calendar + Side panel */}
        <div className="flex gap-6 mb-8">
          <div className="flex-1 bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <button onClick={() => { const d = new Date(current); d.setMonth(d.getMonth()-1); setCurrent(d); }}
                  className="w-7 h-7 flex items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100 text-sm">‹</button>
                <button onClick={() => setCurrent(new Date())}
                  className="px-3 py-1 rounded-lg text-xs font-semibold hover:bg-gray-100 text-gray-600">Today</button>
                <button onClick={() => { const d = new Date(current); d.setMonth(d.getMonth()+1); setCurrent(d); }}
                  className="w-7 h-7 flex items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100 text-sm">›</button>
              </div>
              <h2 className="text-sm font-bold text-gray-800">
                {MONTHS[current.getMonth()]} {current.getFullYear()}
              </h2>
              <Link href="/calendar" className="text-xs font-semibold hover:underline" style={{ color: "#F5A623" }}>
                Full Calendar →
              </Link>
            </div>

            <div className="grid grid-cols-7 border-b border-gray-100">
              {DAYS.map(d => (
                <div key={d} className="py-2 text-center text-xs font-semibold text-gray-400 uppercase">{d}</div>
              ))}
            </div>

            <div className="grid grid-cols-7">
              {getMonthDays().map((date, idx) => {
                if (!date) return (
                  <div key={`e-${idx}`} className="min-h-[80px] border-b border-r border-gray-50 bg-gray-50/50" />
                );
                const key = toKey(date);
                const isToday = key === todayKey;
                const isSelected = key === selectedDate;
                const chips = dispatchMap[key] ?? [];
                return (
                  <div key={key} onClick={() => setSelectedDate(isSelected ? null : key)}
                    className={`min-h-[80px] border-b border-r border-gray-100 p-1.5 cursor-pointer transition-colors
                      ${isSelected ? "bg-amber-50 ring-2 ring-inset ring-amber-400" : "hover:bg-gray-50"}`}>
                    <div className={`text-xs font-bold w-6 h-6 flex items-center justify-center rounded-full mb-1
                      ${isToday ? "text-white" : "text-gray-600"}`}
                      style={isToday ? { background: "#1B2A6B" } : {}}>
                      {date.getDate()}
                    </div>
                    {chips.slice(0, 2).map(d => (
                      <div key={d.id}
                        onClick={e => { e.stopPropagation(); router.push(`/dispatches/${d.id}`); }}
                        className="text-xs rounded px-1.5 py-0.5 truncate mb-0.5 cursor-pointer hover:opacity-80"
                        style={{ background: "rgba(27,42,107,0.1)", color: "#1B2A6B" }}
                        title={d.dispatch_number ?? d.company_name ?? "Dispatch"}>
                        {d.dispatch_number ?? d.company_name ?? "Dispatch"}
                      </div>
                    ))}
                    {chips.length > 2 && (
                      <div className="text-xs pl-1" style={{ color: "#F5A623" }}>+{chips.length - 2} more</div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Side panel */}
          <div className="w-64 shrink-0">
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden sticky top-8">
              <div className="px-4 py-3 border-b border-gray-100" style={{ background: "#F8F9FB" }}>
                <h2 className="text-xs font-bold uppercase tracking-widest text-gray-500">
                  {selectedDate ? (() => {
                    const [y,m,d] = selectedDate.split("-").map(Number);
                    return new Date(y,m-1,d).toLocaleDateString("en-PH", { weekday:"short", month:"long", day:"numeric" });
                  })() : "Select a date"}
                </h2>
              </div>
              <div className="p-4">
                {!selectedDate ? (
                  <p className="text-xs text-gray-400 italic">Click a date on the calendar to see dispatches.</p>
                ) : selectedDispatches.length === 0 ? (
                  <p className="text-xs text-gray-400 italic">No dispatches on this date.</p>
                ) : (
                  <div className="space-y-2">
                    {selectedDispatches.map(d => (
                      <div key={d.id} onClick={() => router.push(`/dispatches/${d.id}`)}
                        className="p-3 rounded-lg border border-gray-100 hover:border-amber-300 hover:bg-amber-50 cursor-pointer transition-colors">
                        <p className="text-xs font-bold" style={{ color: "#1B2A6B" }}>
                          {d.dispatch_number ?? "No Number"}
                        </p>
                        <p className="text-xs text-gray-500 mt-0.5">{d.company_name ?? "—"}</p>
                        <div className="mt-1.5">
                          <StatusBadge date_from={d.date_from} date_to={d.date_to} />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Dispatch list */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h2 className="text-sm font-bold text-gray-800 uppercase tracking-wide">
              {isScheduler ? "All Dispatches" : "My Dispatches"}
            </h2>
            <Link href="/dispatches" className="text-xs font-semibold hover:underline" style={{ color: "#F5A623" }}>
              View All →
            </Link>
          </div>

          {dispatches.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <p className="text-gray-500 font-medium">No dispatches found.</p>
              <p className="text-gray-400 text-xs mt-1">
                {noAssignments ? "You have no dispatches assigned to you yet." : "No dispatch records exist yet."}
              </p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead style={{ background: "#F8F9FB" }}>
                <tr>
                  {["Dispatch #", "Company", "Date From", "Date To", "Status", "Transport", "Created"].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {dispatches.slice(0, 8).map(d => (
                  <tr key={d.id}
                    onClick={() => router.push(`/dispatches/${d.id}`)}
                    className="hover:bg-amber-50 cursor-pointer transition-colors">
                    <td className="px-4 py-3 font-mono text-xs font-bold" style={{ color: "#1B2A6B" }}>
                      {d.dispatch_number ?? "—"}
                    </td>
                    <td className="px-4 py-3 text-gray-700 text-xs">{d.company_name ?? "—"}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{d.date_from ?? "—"}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{d.date_to ?? "—"}</td>
                    <td className="px-4 py-3">
                      <StatusBadge date_from={d.date_from} date_to={d.date_to} />
                    </td>
                    <td className="px-4 py-3 text-gray-500 text-xs">
                      {TRANSPORT_LABELS[d.transport_mode ?? ""] ?? d.transport_mode ?? "—"}
                    </td>
                    <td className="px-4 py-3 text-gray-400 text-xs">
                      {new Date(d.created_at).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

      </div>
    </AppLayout>
  );
}
