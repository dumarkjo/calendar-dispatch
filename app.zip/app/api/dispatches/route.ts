import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";

// ─── GET: fetch all dispatches ────────────────────────────────────────────────
export async function GET(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: userData, error: userErr } = await supabaseAdmin.auth.getUser(token);
  if (userErr || !userData.user)
    return NextResponse.json({ error: "Invalid session" }, { status: 401 });

  const userId = userData.user.id;

  const { data: profile } = await supabaseAdmin
    .from("profiles")
    .select("role")
    .eq("id", userId)
    .single();

  const isScheduler = profile?.role === "scheduler";

  let query = supabaseAdmin
    .from("dispatches")
    .select(`
      id, dispatch_number, company_name, date_from, date_to,
      transport_mode, created_at, type, location,
      dispatch_engineers ( profile_id, profiles ( full_name ) ),
      dispatch_technicians ( profile_id, profiles ( full_name ) )
    `)
    .order("created_at", { ascending: false });

  if (!isScheduler) {
    const [engRes, techRes] = await Promise.all([
      supabaseAdmin.from("dispatch_engineers").select("dispatch_id").eq("profile_id", userId),
      supabaseAdmin.from("dispatch_technicians").select("dispatch_id").eq("profile_id", userId),
    ]);

    const uniqueIds = [
      ...new Set([
        ...(engRes.data ?? []).map((r) => r.dispatch_id),
        ...(techRes.data ?? []).map((r) => r.dispatch_id),
      ]),
    ];

    if (uniqueIds.length === 0) {
      return NextResponse.json({ dispatches: [], noAssignments: true });
    }

    query = query.in("id", uniqueIds);
  }

  const { data: dispatches, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  return NextResponse.json({ dispatches });
}

// ─── Dispatch number generator ────────────────────────────────────────────────
async function generateDispatchNumber(dateFrom: string): Promise<string> {
  const base = `Dis - ${dateFrom}`;

  const { data: existing } = await supabaseAdmin
    .from("dispatches")
    .select("dispatch_number")
    .like("dispatch_number", `${base}%`);

  if (!existing || existing.length === 0) return base;

  const suffixes = existing
    .map((d) => d.dispatch_number?.replace(base, "") ?? "")
    .filter((s) => /^[A-Z]$/.test(s));

  if (suffixes.length === 0) return `${base}A`;

  const lastChar = suffixes.sort().at(-1)!;
  const nextChar = String.fromCharCode(lastChar.charCodeAt(0) + 1);
  return `${base}${nextChar}`;
}

// ─── POST: create dispatch ────────────────────────────────────────────────────
export async function POST(req: Request) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: userData, error: userErr } = await supabaseAdmin.auth.getUser(token);
  if (userErr || !userData.user)
    return NextResponse.json({ error: "Invalid session" }, { status: 401 });

  const user = userData.user;
  const body = await req.json();
  const {
    date_from, date_to, company_name, contact_info,
    transport_mode, transport_other_text, notes,
    remarks_observation, engineer_ids = [], technician_ids = [],
    testing_location, type,
    instruments = [], machines = [],
  } = body;

  const today = new Date().toISOString().split("T")[0];
  const dispatch_number = await generateDispatchNumber(today);

  // ── Insert dispatch ──────────────────────────────────────────────────────────
  const { data: dispatch, error: dispatchErr } = await supabaseAdmin
    .from("dispatches")
    .insert({
      created_by: user.id,
      type: type ?? "on_field",
      location: company_name,
      start_date: date_from,
      end_date: date_to,
      date_from,
      date_to,
      company_name,
      contact_info,
      transport_mode,
      transport_other_text,
      notes,
      remarks_observation,
      dispatch_number,
      testing_location,
    })
    .select()
    .single();

  if (dispatchErr || !dispatch)
    return NextResponse.json({ error: dispatchErr?.message ?? "Insert failed" }, { status: 500 });

  const dispatchId = dispatch.id;

  // ── Helper: rollback on error ────────────────────────────────────────────────
  async function rollback() {
    await supabaseAdmin.from("dispatches").delete().eq("id", dispatchId);
  }

  // ── Engineers ────────────────────────────────────────────────────────────────
  if (engineer_ids.length > 0) {
    const { error: engErr } = await supabaseAdmin
      .from("dispatch_engineers")
      .insert(engineer_ids.map((id: string) => ({ dispatch_id: dispatchId, profile_id: id })));
    if (engErr) { await rollback(); return NextResponse.json({ error: engErr.message }, { status: 500 }); }
  }

  // ── Technicians ──────────────────────────────────────────────────────────────
  if (technician_ids.length > 0) {
    const { error: techErr } = await supabaseAdmin
      .from("dispatch_technicians")
      .insert(technician_ids.map((id: string) => ({ dispatch_id: dispatchId, profile_id: id })));
    if (techErr) { await rollback(); return NextResponse.json({ error: techErr.message }, { status: 500 }); }
  }

  // ── Instruments ──────────────────────────────────────────────────────────────
  if (instruments.length > 0) {
    const { error: instErr } = await supabaseAdmin
      .from("dispatch_instruments")
      .insert(
        instruments.map((inst: any) => ({
          dispatch_id: dispatchId,
          instrument_name: inst.instrument_name,
          code_brand_model: inst.code_brand_model,
          before_travel: inst.before_travel,
          remarks: inst.remarks,
        }))
      );
    if (instErr) { await rollback(); return NextResponse.json({ error: instErr.message }, { status: 500 }); }
  }

  // ── Machines ─────────────────────────────────────────────────────────────────
  if (machines.length > 0) {
    const { error: machErr } = await supabaseAdmin
      .from("dispatch_machines")
      .insert(
        machines.map((m: any) => ({
          dispatch_id: dispatchId,
          tam_no: m.tam_no,
          machine: m.machine,
          brand: m.brand,
          model: m.model,
          serial_no: m.serial_no,
          date_of_test: m.date_of_test || null,
          status: m.status || null,
        }))
      );
    if (machErr) { await rollback(); return NextResponse.json({ error: machErr.message }, { status: 500 }); }
  }

  return NextResponse.json({ dispatch });
}
