import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { execFile } from "child_process";
import { promisify } from "util";
import path from "path";

const execFileAsync = promisify(execFile);

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  // ── Auth ─────────────────────────────────────────────────────────────────
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token)
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: userData, error: userErr } =
    await supabaseAdmin.auth.getUser(token);
  if (userErr || !userData.user)
    return NextResponse.json({ error: "Invalid session" }, { status: 401 });

  const { id } = await params;

  // ── Fetch dispatch ────────────────────────────────────────────────────────
  const { data: dispatch, error } = await supabaseAdmin
    .from("dispatches")
    .select(
      `
      *,
      dispatch_engineers ( id, profile_id, profiles ( full_name, role ) ),
      dispatch_technicians ( id, profile_id, profiles ( full_name, role ) ),
      dispatch_instruments ( * ),
      dispatch_itinerary ( * ),
      dispatch_machines ( * )
    `
    )
    .eq("id", id)
    .single();

  if (error || !dispatch)
    return NextResponse.json({ error: error?.message ?? "Not found" }, { status: 404 });

  // ── Generate PDF via Python script ────────────────────────────────────────
  const scriptPath = path.join(process.cwd(), "scripts", "generate_dispatch_pdf.py");

  let stdout: Buffer;
  try {
    const result = await execFileAsync(
      "python3",
      [scriptPath],
      {
        input: JSON.stringify(dispatch),
        encoding: "buffer",
        maxBuffer: 10 * 1024 * 1024, // 10 MB
      } as any
    );
    stdout = (result as any).stdout as Buffer;
  } catch (err: any) {
    console.error("PDF generation error:", err?.stderr?.toString());
    return NextResponse.json(
      { error: "Failed to generate PDF" },
      { status: 500 }
    );
  }

  // ── Return PDF ────────────────────────────────────────────────────────────
  const filename = `dispatch-${dispatch.dispatch_number ?? id}.pdf`;

  return new NextResponse(stdout, {
    status: 200,
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Content-Length": String(stdout.length),
    },
  });
}
