import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: userData, error: userErr } = await supabaseAdmin.auth.getUser(token);
  if (userErr || !userData.user)
    return NextResponse.json({ error: "Invalid session" }, { status: 401 });

  const { id } = await params;

  const { data: dispatch, error } = await supabaseAdmin
    .from("dispatches")
    .select(`
      *,
      dispatch_engineers ( id, profile_id, profiles ( full_name, role ) ),
      dispatch_technicians ( id, profile_id, profiles ( full_name, role ) ),
      dispatch_instruments ( * ),
      dispatch_itinerary ( * ),
      dispatch_machines ( * )
    `)
    .eq("id", id)
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  if (!dispatch) return NextResponse.json({ error: "Not found" }, { status: 404 });

  return NextResponse.json({ dispatch });
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: userData, error: userErr } = await supabaseAdmin.auth.getUser(token);
  if (userErr || !userData.user)
    return NextResponse.json({ error: "Invalid session" }, { status: 401 });

  const user = userData.user;
  const { id } = await params;
  const body = await req.json();

  const {
    date_from, date_to, company_name, contact_info,
    transport_mode, transport_other_text, notes,
    remarks_observation, testing_location, type,
    engineer_ids = [], technician_ids = [],
    instruments, machines,
  } = body;

  // ── Update main dispatch record ──────────────────────────────────────────────
  const { error: updateErr } = await supabaseAdmin
    .from("dispatches")
    .update({
      date_from,
      date_to,
      start_date: date_from,
      end_date: date_to,
      company_name,
      contact_info,
      transport_mode,
      transport_other_text,
      notes,
      remarks_observation,
      testing_location,
      type,
      location: company_name,
      updated_by: user.id,
      updated_at: new Date().toISOString(),
    })
    .eq("id", id);

  if (updateErr)
    return NextResponse.json({ error: updateErr.message }, { status: 500 });

  // ── Replace engineers ────────────────────────────────────────────────────────
  await supabaseAdmin.from("dispatch_engineers").delete().eq("dispatch_id", id);
  if (engineer_ids.length > 0) {
    const { error: engErr } = await supabaseAdmin
      .from("dispatch_engineers")
      .insert(engineer_ids.map((pid: string) => ({ dispatch_id: id, profile_id: pid })));
    if (engErr) return NextResponse.json({ error: engErr.message }, { status: 500 });
  }

  // ── Replace technicians ──────────────────────────────────────────────────────
  await supabaseAdmin.from("dispatch_technicians").delete().eq("dispatch_id", id);
  if (technician_ids.length > 0) {
    const { error: techErr } = await supabaseAdmin
      .from("dispatch_technicians")
      .insert(technician_ids.map((pid: string) => ({ dispatch_id: id, profile_id: pid })));
    if (techErr) return NextResponse.json({ error: techErr.message }, { status: 500 });
  }

  // ── Replace instruments (only if provided in body) ───────────────────────────
  if (instruments !== undefined) {
    await supabaseAdmin.from("dispatch_instruments").delete().eq("dispatch_id", id);
    if (instruments.length > 0) {
      const { error: instErr } = await supabaseAdmin
        .from("dispatch_instruments")
        .insert(
          instruments.map((inst: any) => ({
            dispatch_id: id,
            instrument_name: inst.instrument_name,
            code_brand_model: inst.code_brand_model,
            before_travel: inst.before_travel,
            remarks: inst.remarks,
          }))
        );
      if (instErr) return NextResponse.json({ error: instErr.message }, { status: 500 });
    }
  }

  // ── Replace machines (only if provided in body) ──────────────────────────────
  if (machines !== undefined) {
    await supabaseAdmin.from("dispatch_machines").delete().eq("dispatch_id", id);
    if (machines.length > 0) {
      const { error: machErr } = await supabaseAdmin
        .from("dispatch_machines")
        .insert(
          machines.map((m: any) => ({
            dispatch_id: id,
            tam_no: m.tam_no,
            machine: m.machine,
            brand: m.brand,
            model: m.model,
            serial_no: m.serial_no,
            date_of_test: m.date_of_test || null,
            status: m.status || null,
          }))
        );
      if (machErr) return NextResponse.json({ error: machErr.message }, { status: 500 });
    }
  }

  // ── Fetch and return updated dispatch ────────────────────────────────────────
  const { data: dispatch, error: fetchErr } = await supabaseAdmin
    .from("dispatches")
    .select(`
      *,
      dispatch_engineers ( id, profile_id, profiles ( full_name, role ) ),
      dispatch_technicians ( id, profile_id, profiles ( full_name, role ) ),
      dispatch_instruments ( * ),
      dispatch_itinerary ( * ),
      dispatch_machines ( * )
    `)
    .eq("id", id)
    .single();

  if (fetchErr) return NextResponse.json({ error: fetchErr.message }, { status: 500 });

  return NextResponse.json({ dispatch });
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: userData, error: userErr } = await supabaseAdmin.auth.getUser(token);
  if (userErr || !userData.user)
    return NextResponse.json({ error: "Invalid session" }, { status: 401 });

  const { id } = await params;

  const { error } = await supabaseAdmin.from("dispatches").delete().eq("id", id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  return NextResponse.json({ success: true });
}
