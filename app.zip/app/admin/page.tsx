'use client'

import { useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import AppLayout from '../components/AppLayout'
import { supabaseBrowser } from '@/lib/supabase/client'

type Profile = {
  id: string
  full_name: string
  email: string
  role: string
  active: boolean
  created_at: string
}

const ROLES = ['engineer', 'technician', 'scheduler', 'admin']

const roleBadge: Record<string, string> = {
  engineer: 'bg-blue-100 text-blue-800',
  technician: 'bg-purple-100 text-purple-800',
  scheduler: 'bg-amber-100 text-amber-800',
  admin: 'bg-red-100 text-red-800',
}

export default function AdminPage() {
  const router = useRouter()
  const supabase = useMemo(() => supabaseBrowser(), [])  // ✅ only one declaration

  const [users, setUsers] = useState<Profile[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [saving, setSaving] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [filterRole, setFilterRole] = useState('all')
  const [filterActive, setFilterActive] = useState('all')

  // ❌ DELETE the old: const supabase = supabaseBrowser()
  // ❌ DELETE the old: const getToken = async () => { ... }

  useEffect(() => {
    const init = async () => {
      const { data } = await supabase.auth.getUser()
      if (!data.user) { router.push('/login'); return }

      const meRes = await fetch('/api/me', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: data.user.id }),
      })
      const meData = await meRes.json()
      const userRole = meData.profile?.role ?? ''

      if (!['scheduler', 'admin'].includes(userRole)) {
        router.push('/dashboard')
        return
      }

      const { data: session } = await supabase.auth.getSession()
      const token = session.session?.access_token
      if (!token) { router.push('/login'); return }

      fetchUsers(token)
    }
    init()
  }, [router, supabase])

  const fetchUsers = async (token: string) => {
    setLoading(true)
    const res = await fetch('/api/admin/users', {
        headers: { Authorization: `Bearer ${token}` },
    })
    console.log('Status:', res.status)
    const text = await res.text()
    console.log('Response:', text)
    try {
        const data = JSON.parse(text)
        if (res.ok) setUsers(data)
        else setError(data.error ?? 'Failed to load users')
    } catch {
        setError('Invalid response from server')
    }
    setLoading(false)
  }

  const updateUser = async (id: string, updates: { active?: boolean; role?: string }) => {
    setSaving(id)
    const { data: session } = await supabase.auth.getSession()
    const token = session.session?.access_token
    const res = await fetch(`/api/admin/users/${id}`, {
        method: 'PUT',
        headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        },
        body: JSON.stringify(updates),
    })
    const data = await res.json()
    if (res.ok) {
        setUsers(prev => prev.map(u => (u.id === id ? { ...u, ...data } : u)))
    }
    setSaving(null)
  }

  const deleteUser = async (id: string, name: string) => {
    if (!confirm(`Are you sure you want to delete "${name}"? This cannot be undone.`)) return

    setSaving(id)
    const { data: session } = await supabase.auth.getSession()
    const token = session.session?.access_token
    const res = await fetch(`/api/admin/users/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
    })
    if (res.ok) {
        setUsers(prev => prev.filter(u => u.id !== id))
    } else {
        const data = await res.json()
        alert(data.error ?? 'Failed to delete user')
    }
    setSaving(null)
  }

  const filtered = users.filter(u => {
    const matchSearch = u.full_name.toLowerCase().includes(search.toLowerCase())
    const matchRole = filterRole === 'all' || u.role === filterRole
    const matchActive =
      filterActive === 'all' ||
      (filterActive === 'active' && u.active) ||
      (filterActive === 'inactive' && !u.active)
    return matchSearch && matchRole && matchActive
  })

  const pendingCount = users.filter(u => !u.active).length

  return (
    <AppLayout>
      <div className="p-6 max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-[#1B2A6B]">Admin Panel</h1>
              <p className="text-gray-500 mt-1 text-sm">Manage user accounts, roles, and access</p>
            </div>
            {pendingCount > 0 && (
              <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 text-amber-800 px-4 py-2 rounded-lg text-sm font-medium">
                <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-amber-500 text-white text-xs font-bold">
                  {pendingCount}
                </span>
                pending activation{pendingCount > 1 ? 's' : ''}
              </div>
            )}
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">
            {[
              { label: 'Total Users', value: users.length, color: 'text-[#1B2A6B]' },
              { label: 'Active', value: users.filter(u => u.active).length, color: 'text-green-600' },
              { label: 'Inactive', value: users.filter(u => !u.active).length, color: 'text-red-500' },
              { label: 'Engineers', value: users.filter(u => u.role === 'engineer').length, color: 'text-blue-600' },
            ].map(s => (
              <div key={s.label} className="bg-white rounded-xl border border-gray-100 shadow-sm px-4 py-3">
                <p className="text-xs text-gray-400 uppercase tracking-wide">{s.label}</p>
                <p className={`text-2xl font-bold mt-1 ${s.color}`}>{s.value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-5">
          <input
            type="text"
            placeholder="Search by name..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1B2A6B]/20 w-56"
          />
          <select
            value={filterRole}
            onChange={e => setFilterRole(e.target.value)}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1B2A6B]/20"
          >
            <option value="all">All Roles</option>
            {ROLES.map(r => (
              <option key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</option>
            ))}
          </select>
          <select
            value={filterActive}
            onChange={e => setFilterActive(e.target.value)}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1B2A6B]/20"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>

        {/* Table */}
        {loading ? (
          <div className="text-center py-20 text-gray-400">Loading users...</div>
        ) : error ? (
          <div className="text-center py-20 text-red-500">{error}</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20 text-gray-400">No users found.</div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-[#F4F6FB] border-b border-gray-100">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Name</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Email</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Role</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Joined</th>
                  <th className="text-right px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((user, i) => (
                  <tr
                    key={user.id}
                    className={`border-b border-gray-50 hover:bg-[#F4F6FB]/60 transition-colors ${
                      i % 2 === 0 ? '' : 'bg-gray-50/30'
                    }`}
                  >
                    {/* Name selector */}
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                          style={{ backgroundColor: '#1B2A6B' }}
                        >
                          {user.full_name?.charAt(0)?.toUpperCase() ?? '?'}
                        </div>
                        <span className="font-medium text-gray-800">{user.full_name}</span>
                      </div>
                    </td>

                    {/* Email selector */}
                    <td className="px-5 py-4 text-gray-500 text-xs">{user.email}</td>

                    {/* Role selector */}
                    <td className="px-5 py-4">
                      <select
                        value={user.role}
                        disabled={saving === user.id}
                        onChange={e => updateUser(user.id, { role: e.target.value })}
                        className={`text-xs font-semibold px-2 py-1 rounded-full border-0 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#1B2A6B]/20 ${
                          roleBadge[user.role] ?? 'bg-gray-100 text-gray-700'
                        }`}
                      >
                        {ROLES.map(r => (
                          <option key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</option>
                        ))}
                      </select>
                    </td>

                    {/* Active toggle */}
                    <td className="px-5 py-4">
                      <button
                        onClick={() => updateUser(user.id, { active: !user.active })}
                        disabled={saving === user.id}
                        className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                          user.active
                            ? 'bg-green-100 text-green-700 hover:bg-green-200'
                            : 'bg-red-100 text-red-600 hover:bg-red-200'
                        } disabled:opacity-50`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${user.active ? 'bg-green-500' : 'bg-red-400'}`} />
                        {saving === user.id ? 'Saving...' : user.active ? 'Active' : 'Inactive'}
                      </button>
                    </td>

                    <td className="px-5 py-4 text-gray-400 text-xs">
                      {new Date(user.created_at).toLocaleDateString('en-PH', {
                        year: 'numeric', month: 'short', day: 'numeric',
                      })}
                    </td>

                    <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                            {!user.active ? (
                            <button
                                onClick={() => updateUser(user.id, { active: true })}
                                disabled={saving === user.id}
                                className="bg-[#1B2A6B] hover:bg-[#0F1A4A] text-white text-xs font-semibold px-4 py-1.5 rounded-lg transition-colors disabled:opacity-50"
                            >
                                Activate
                            </button>
                            ) : (
                            <button
                                onClick={() => updateUser(user.id, { active: false })}
                                disabled={saving === user.id}
                                className="bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-semibold px-4 py-1.5 rounded-lg transition-colors disabled:opacity-50"
                            >
                                Deactivate
                            </button>
                            )}
                            <button
                            onClick={() => deleteUser(user.id, user.full_name)}
                            disabled={saving === user.id}
                            className="bg-red-50 hover:bg-red-100 text-red-600 text-xs font-semibold px-4 py-1.5 rounded-lg transition-colors disabled:opacity-50"
                            >
                            Delete
                            </button>
                        </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppLayout>
  )
}