"use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import AppLayout from "../../../components/AppLayout";

type TransportMode =
  | "public_conveyance"
  | "test_applicant_vehicle"
  | "college_vehicle"
  | "other";

type Tab = "basic" | "instruments" | "itinerary" | "machines";

type InstrumentOption = {
  id: string;
  instrument_name: string;
  type: string | null;
  brand: string | null;
  model: string | null;
  instrument_code: string | null;
};

type SelectedInstrument = {
  rowId: string;
  instrument_id: string;
  instrument_name: string;
  code_brand_model: string;
  before_travel: string;
  remarks: string;
};

type Machine = {
  id: string;
  tam_no: string;
  machine: string;
  brand: string;
  model: string;
  serial_no: string;
  date_of_test: string;
  status: string;
};

function newMachine(): Machine {
  return { id: crypto.randomUUID(), tam_no: "", machine: "", brand: "", model: "", serial_no: "", date_of_test: "", status: "" };
}

function newSelectedInstrument(): SelectedInstrument {
  return { rowId: crypto.randomUUID(), instrument_id: "", instrument_name: "", code_brand_model: "", before_travel: "", remarks: "" };
}

export default function EditDispatchPage() {
  const router = useRouter();
  const { id } = useParams<{ id: string }>();
  const supabase = useMemo(() => supabaseBrowser(), []);

  const [activeTab, setActiveTab] = useState<Tab>("basic");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [msgType, setMsgType] = useState<"success" | "error">("error");
  const [dispatchNumber, setDispatchNumber] = useState("");

  // Basic Info
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [contactInfo, setContactInfo] = useState("");
  const [transportMode, setTransportMode] = useState<TransportMode>("public_conveyance");
  const [transportOther, setTransportOther] = useState("");
  const [notes, setNotes] = useState("");
  const [remarks, setRemarks] = useState("");
  const [locationType, setLocationType] = useState<"amtec" | "clients_place">("amtec");
  const [testingLocation, setTestingLocation] = useState("");

  // Personnel
  const [engineers, setEngineers] = useState<any[]>([]);
  const [technicians, setTechnicians] = useState<any[]>([]);
  const [selectedEngineerIds, setSelectedEngineerIds] = useState<string[]>([]);
  const [selectedTechnicianIds, setSelectedTechnicianIds] = useState<string[]>([]);

  // Instruments
  const [instrumentOptions, setInstrumentOptions] = useState<InstrumentOption[]>([]);
  const [selectedInstruments, setSelectedInstruments] = useState<SelectedInstrument[]>([newSelectedInstrument()]);
  const [instrumentSearch, setInstrumentSearch] = useState<Record<string, string>>({});
  const [instrumentDropdownOpen, setInstrumentDropdownOpen] = useState<Record<string, boolean>>({});

  // Machines
  const [machines, setMachines] = useState<Machine[]>([newMachine()]);

  useEffect(() => {
    let cancelled = false;
    async function loadAll() {
      const { data } = await supabase.auth.getUser();
      if (!data.user) { router.push("/login"); return; }

      const meRes = await fetch("/api/me", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: data.user.id }),
      });
      const meData = await meRes.json();
      const userRole = meData.profile?.role ?? "";
      if (!["scheduler", "admin"].includes(userRole)) { router.push("/dashboard"); return; }

      const { data: session } = await supabase.auth.getSession();
      const token = session.session?.access_token;
      if (!token) { router.push("/login"); return; }

      const [dispatchRes, engRes, techRes, instRes] = await Promise.all([
        fetch(`/api/dispatches/${id}`, { headers: { Authorization: `Bearer ${token}` } }),
        fetch("/api/staff/engineers"),
        fetch("/api/staff/technicians"),
        fetch("/api/instruments"),
      ]);

      const dispatchJson = await dispatchRes.json();
      const engData = await engRes.json();
      const techData = await techRes.json();
      const instData = await instRes.json();

      if (cancelled) return;
      if (!dispatchRes.ok) { router.push("/dispatches"); return; }

      const d = dispatchJson.dispatch;

      // Basic Info
      setDispatchNumber(d.dispatch_number ?? "");
      setDateFrom(d.date_from ?? "");
      setDateTo(d.date_to ?? "");
      setCompanyName(d.company_name ?? "");
      setContactInfo(d.contact_info ?? "");
      setTransportMode(d.transport_mode ?? "public_conveyance");
      setTransportOther(d.transport_other_text ?? "");
      setNotes(d.notes ?? "");
      setRemarks(d.remarks_observation ?? "");
      if (d.type === "in_house") {
        setLocationType("amtec");
        setTestingLocation("");
      } else {
        setLocationType("clients_place");
        setTestingLocation(d.testing_location ?? "");
      }

      // Personnel
      setEngineers(engData.staff ?? []);
      setTechnicians(techData.staff ?? []);
      setSelectedEngineerIds((d.dispatch_engineers ?? []).map((e: any) => e.profile_id));
      setSelectedTechnicianIds((d.dispatch_technicians ?? []).map((t: any) => t.profile_id));

      // Instruments — map existing dispatch_instruments back to SelectedInstrument shape
      const allInstruments: InstrumentOption[] = instData.instruments ?? [];
      setInstrumentOptions(allInstruments);

      const existingInstruments: SelectedInstrument[] = (d.dispatch_instruments ?? []).map((inst: any) => {
        // Try to find matching instrument in the options list by name
        const match = allInstruments.find(o => o.instrument_name === inst.instrument_name);
        return {
          rowId: crypto.randomUUID(),
          instrument_id: match?.id ?? "",
          instrument_name: inst.instrument_name ?? "",
          code_brand_model: inst.code_brand_model ?? "",
          before_travel: inst.before_travel ?? "",
          remarks: inst.remarks ?? "",
        };
      });
      setSelectedInstruments(existingInstruments.length > 0 ? existingInstruments : [newSelectedInstrument()]);

      // Restore instrument search labels
      const searchMap: Record<string, string> = {};
      existingInstruments.forEach(i => { searchMap[i.rowId] = i.instrument_name; });
      setInstrumentSearch(searchMap);

      // Machines
      const existingMachines: Machine[] = (d.dispatch_machines ?? []).map((m: any) => ({
        id: crypto.randomUUID(),
        tam_no: m.tam_no ?? "",
        machine: m.machine ?? "",
        brand: m.brand ?? "",
        model: m.model ?? "",
        serial_no: m.serial_no ?? "",
        date_of_test: m.date_of_test ?? "",
        status: m.status ?? "",
      }));
      setMachines(existingMachines.length > 0 ? existingMachines : [newMachine()]);

      setLoading(false);
    }
    loadAll();
    return () => { cancelled = true; };
  }, [id, router, supabase]);

  // ── Personnel helpers ───────────────────────────────────────────────────────
  function toggleEngineer(pid: string) {
    setSelectedEngineerIds(prev => prev.includes(pid) ? prev.filter(x => x !== pid) : [...prev, pid]);
  }
  function toggleTechnician(pid: string) {
    setSelectedTechnicianIds(prev => prev.includes(pid) ? prev.filter(x => x !== pid) : [...prev, pid]);
  }

  // ── Instrument helpers ──────────────────────────────────────────────────────
  function getFilteredOptions(rowId: string): InstrumentOption[] {
    const search = (instrumentSearch[rowId] ?? "").toLowerCase();
    if (!search) return instrumentOptions;
    return instrumentOptions.filter(o =>
      o.instrument_name.toLowerCase().includes(search) ||
      (o.instrument_code ?? "").toLowerCase().includes(search) ||
      (o.brand ?? "").toLowerCase().includes(search) ||
      (o.type ?? "").toLowerCase().includes(search)
    );
  }

  function selectInstrumentOption(rowId: string, option: InstrumentOption) {
    const codeBrandModel = [option.instrument_code, option.brand, option.model].filter(Boolean).join(" / ");
    setSelectedInstruments(prev => prev.map(i =>
      i.rowId === rowId
        ? { ...i, instrument_id: option.id, instrument_name: option.instrument_name, code_brand_model: codeBrandModel }
        : i
    ));
    setInstrumentSearch(prev => ({ ...prev, [rowId]: option.instrument_name }));
    setInstrumentDropdownOpen(prev => ({ ...prev, [rowId]: false }));
  }

  function updateInstrument(rowId: string, field: keyof SelectedInstrument, value: string) {
    setSelectedInstruments(prev => prev.map(i => i.rowId === rowId ? { ...i, [field]: value } : i));
  }

  function addInstrumentRow() { setSelectedInstruments(prev => [...prev, newSelectedInstrument()]); }
  function removeInstrumentRow(rowId: string) {
    setSelectedInstruments(prev => prev.length > 1 ? prev.filter(i => i.rowId !== rowId) : prev);
  }

  // ── Machine helpers ─────────────────────────────────────────────────────────
  function updateMachine(id: string, field: keyof Machine, value: string) {
    setMachines(prev => prev.map(m => m.id === id ? { ...m, [field]: value } : m));
  }
  function addMachine() { setMachines(prev => [...prev, newMachine()]); }
  function removeMachine(id: string) {
    setMachines(prev => prev.length > 1 ? prev.filter(m => m.id !== id) : prev);
  }

  // ── Delete ──────────────────────────────────────────────────────────────────
  async function deleteDispatch() {
    if (!confirm("Are you sure you want to delete this dispatch? This cannot be undone.")) return;
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData.session?.access_token;
    if (!token) { setMsg("Error: Not authenticated"); return; }

    const res = await fetch(`/api/dispatches/${id}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) {
      const data = await res.json();
      setMsgType("error");
      setMsg(`Error: ${data.error ?? "Delete failed"}`);
      return;
    }
    router.push("/dashboard");
  }

  // ── Save ────────────────────────────────────────────────────────────────────
  async function saveDispatch() {
    setSaving(true);
    setMsg("");

    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData.session?.access_token;
    if (!token) { setMsg("Error: Not authenticated"); setSaving(false); return; }

    const cleanInstruments = selectedInstruments
      .filter(i => i.instrument_name.trim() !== "")
      .map(({ rowId, ...rest }) => rest);

    const cleanMachines = machines
      .filter(m => m.machine.trim() !== "")
      .map(({ id, ...rest }) => rest);

    const res = await fetch(`/api/dispatches/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        date_from: dateFrom,
        date_to: dateTo,
        company_name: companyName,
        contact_info: contactInfo,
        transport_mode: transportMode,
        transport_other_text: transportMode === "other" ? transportOther : null,
        notes,
        remarks_observation: remarks,
        testing_location: locationType === "clients_place" ? testingLocation : "AMTEC",
        type: locationType === "amtec" ? "in_house" : "on_field",
        engineer_ids: selectedEngineerIds,
        technician_ids: selectedTechnicianIds,
        instruments: cleanInstruments,
        machines: cleanMachines,
      }),
    });

    const data = await res.json();
    setSaving(false);
    if (!res.ok) { setMsgType("error"); setMsg(`Error: ${data.error ?? "Unknown error"}`); return; }
    setMsgType("success");
    setMsg("Dispatch updated! Redirecting...");
    setTimeout(() => router.push(`/dispatches/${id}`), 1000);
  }

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#F4F6FB" }}>
      <p className="text-gray-400 text-sm">Loading dispatch...</p>
    </div>
  );

  const tabs: { key: Tab; label: string }[] = [
    { key: "basic", label: "Basic Info" },
    { key: "instruments", label: `Instruments${selectedInstruments.some(i => i.instrument_name) ? ` (${selectedInstruments.filter(i => i.instrument_name).length})` : ""}` },
    { key: "itinerary", label: "Itinerary" },
    { key: "machines", label: `Machines${machines.some(m => m.machine) ? ` (${machines.filter(m => m.machine).length})` : ""}` },
  ];

  const inputClass = "w-full px-3 py-2.5 rounded-lg border text-sm outline-none focus:ring-2 focus:ring-blue-100";
  const inputStyle = { borderColor: "#D1D5DB", color: "#111827" };
  const labelClass = "block text-xs font-semibold uppercase tracking-wide text-gray-500 mb-1.5";

  return (
    <AppLayout>
      <div className="p-8 max-w-5xl">

        {/* Header */}
        <div className="mb-8">
          <p className="text-xs font-semibold uppercase tracking-widest mb-1" style={{ color: "#F5A623" }}>
            Dispatch Management
          </p>
          <h1 className="text-2xl font-black text-gray-900">Edit Dispatch</h1>
          <p className="text-sm font-mono text-gray-500 mt-1">{dispatchNumber}</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">

          {/* Tab Bar */}
          <div className="flex border-b border-gray-200" style={{ background: "#F8F9FB" }}>
            {tabs.map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className="px-6 py-3.5 text-xs font-bold uppercase tracking-widest transition-all"
                style={{
                  color: activeTab === tab.key ? "#1B2A6B" : "#9CA3AF",
                  borderBottom: activeTab === tab.key ? "2px solid #1B2A6B" : "2px solid transparent",
                  background: "transparent",
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* ── TAB: Basic Info ─────────────────────────────────────────────── */}
          {activeTab === "basic" && (
            <>
              {/* Schedule */}
              <div className="px-6 py-4 border-b border-gray-100" style={{ background: "#F8F9FB" }}>
                <h2 className="text-xs font-bold uppercase tracking-widest text-gray-500">Schedule</h2>
              </div>
              <div className="px-6 py-5 grid grid-cols-1 md:grid-cols-2 gap-4 border-b border-gray-100">
                <div>
                  <label className={labelClass}>Date From</label>
                  <input type="date" className={inputClass} style={inputStyle}
                    value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
                </div>
                <div>
                  <label className={labelClass}>Date To</label>
                  <input type="date" className={inputClass} style={inputStyle}
                    value={dateTo} onChange={e => setDateTo(e.target.value)} />
                </div>
              </div>

              {/* Personnel — Checkboxes */}
              <div className="px-6 py-4 border-b border-gray-100" style={{ background: "#F8F9FB" }}>
                <h2 className="text-xs font-bold uppercase tracking-widest text-gray-500">Personnel Assignment</h2>
              </div>
              <div className="px-6 py-5 grid grid-cols-1 md:grid-cols-2 gap-6 border-b border-gray-100">
                <div>
                  <label className={labelClass}>
                    Engineers
                    {selectedEngineerIds.length > 0 && (
                      <span className="ml-2 normal-case font-normal text-blue-500">{selectedEngineerIds.length} selected</span>
                    )}
                  </label>
                  {engineers.length === 0 ? (
                    <p className="text-xs text-gray-400 italic">No engineers available.</p>
                  ) : (
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {engineers.map(p => (
                        <label key={p.id}
                          className="flex items-center gap-3 px-3 py-2.5 rounded-lg border cursor-pointer transition-all"
                          style={{
                            borderColor: selectedEngineerIds.includes(p.id) ? "#1B2A6B" : "#E5E7EB",
                            background: selectedEngineerIds.includes(p.id) ? "#EEF1FB" : "white",
                          }}>
                          <input type="checkbox" checked={selectedEngineerIds.includes(p.id)}
                            onChange={() => toggleEngineer(p.id)}
                            className="rounded" style={{ accentColor: "#1B2A6B" }} />
                          <span className="text-sm text-gray-800">{p.full_name}</span>
                        </label>
                      ))}
                    </div>
                  )}
                </div>
                <div>
                  <label className={labelClass}>
                    Technicians
                    {selectedTechnicianIds.length > 0 && (
                      <span className="ml-2 normal-case font-normal text-blue-500">{selectedTechnicianIds.length} selected</span>
                    )}
                  </label>
                  {technicians.length === 0 ? (
                    <p className="text-xs text-gray-400 italic">No technicians available.</p>
                  ) : (
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {technicians.map(p => (
                        <label key={p.id}
                          className="flex items-center gap-3 px-3 py-2.5 rounded-lg border cursor-pointer transition-all"
                          style={{
                            borderColor: selectedTechnicianIds.includes(p.id) ? "#1B2A6B" : "#E5E7EB",
                            background: selectedTechnicianIds.includes(p.id) ? "#EEF1FB" : "white",
                          }}>
                          <input type="checkbox" checked={selectedTechnicianIds.includes(p.id)}
                            onChange={() => toggleTechnician(p.id)}
                            className="rounded" style={{ accentColor: "#1B2A6B" }} />
                          <span className="text-sm text-gray-800">{p.full_name}</span>
                        </label>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Company & Transport */}
              <div className="px-6 py-4 border-b border-gray-100" style={{ background: "#F8F9FB" }}>
                <h2 className="text-xs font-bold uppercase tracking-widest text-gray-500">Company & Transport</h2>
              </div>
              <div className="px-6 py-5 grid grid-cols-1 md:grid-cols-2 gap-4 border-b border-gray-100">
                <div>
                  <label className={labelClass}>Company Name</label>
                  <input className={inputClass} style={inputStyle}
                    value={companyName} onChange={e => setCompanyName(e.target.value)}
                    placeholder="e.g. Sample Company" />
                </div>
                <div>
                  <label className={labelClass}>Contact Person / Info</label>
                  <input className={inputClass} style={inputStyle}
                    value={contactInfo} onChange={e => setContactInfo(e.target.value)}
                    placeholder="e.g. Juan Dela Cruz - 0912..." />
                </div>
                <div className="md:col-span-2">
                  <label className={labelClass}>Location of Testing</label>
                  <div className="flex gap-6 mb-3">
                    <label className="flex items-center gap-2 cursor-pointer text-sm text-gray-700">
                      <input type="radio" name="locationType" value="amtec"
                        checked={locationType === "amtec"}
                        onChange={() => { setLocationType("amtec"); setTestingLocation(""); }} />
                      AMTEC
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer text-sm text-gray-700">
                      <input type="radio" name="locationType" value="clients_place"
                        checked={locationType === "clients_place"}
                        onChange={() => setLocationType("clients_place")} />
                      Client's Place
                    </label>
                  </div>
                  {locationType === "clients_place" && (
                    <input className={inputClass} style={inputStyle}
                      value={testingLocation} onChange={e => setTestingLocation(e.target.value)}
                      placeholder="e.g. Brgy. Pulo, Cabuyao, Laguna" />
                  )}
                </div>
                <div>
                  <label className={labelClass}>Mode of Transportation</label>
                  <select className={inputClass} style={inputStyle}
                    value={transportMode} onChange={e => setTransportMode(e.target.value as TransportMode)}>
                    <option value="public_conveyance">Public Conveyance</option>
                    <option value="test_applicant_vehicle">Test Applicant Vehicle</option>
                    <option value="college_vehicle">College Vehicle</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                {transportMode === "other" && (
                  <div>
                    <label className={labelClass}>Specify Transport</label>
                    <input className={inputClass} style={inputStyle}
                      value={transportOther} onChange={e => setTransportOther(e.target.value)}
                      placeholder="Enter transport mode" />
                  </div>
                )}
              </div>

              {/* Notes */}
              <div className="px-6 py-4 border-b border-gray-100" style={{ background: "#F8F9FB" }}>
                <h2 className="text-xs font-bold uppercase tracking-widest text-gray-500">Additional Information</h2>
              </div>
              <div className="px-6 py-5 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className={labelClass}>Remarks / Observation</label>
                  <textarea rows={4} className="w-full px-3 py-2.5 rounded-lg border text-sm outline-none resize-none"
                    style={inputStyle} value={remarks} onChange={e => setRemarks(e.target.value)} />
                </div>
                <div>
                  <label className={labelClass}>Notes</label>
                  <textarea rows={4} className="w-full px-3 py-2.5 rounded-lg border text-sm outline-none resize-none"
                    style={inputStyle} value={notes} onChange={e => setNotes(e.target.value)} />
                </div>
              </div>
            </>
          )}

          {/* ── TAB: Instruments ────────────────────────────────────────────── */}
          {activeTab === "instruments" && (
            <div className="px-6 py-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-sm font-bold text-gray-800">Instruments for Dispatch</h2>
                  <p className="text-xs text-gray-400 mt-0.5">Search and select instruments to include in this dispatch.</p>
                </div>
                <button onClick={addInstrumentRow}
                  className="px-4 py-2 rounded-lg text-xs font-bold transition-all hover:opacity-90"
                  style={{ background: "#1B2A6B", color: "white" }}>
                  + Add Instrument
                </button>
              </div>

              <div className="space-y-3">
                {selectedInstruments.map((inst, idx) => {
                  const filtered = getFilteredOptions(inst.rowId);
                  const isOpen = instrumentDropdownOpen[inst.rowId] ?? false;

                  return (
                    <div key={inst.rowId} className="rounded-lg border border-gray-200 p-4" style={{ background: "#F8F9FB" }}>
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Instrument {idx + 1}</span>
                        {selectedInstruments.length > 1 && (
                          <button onClick={() => removeInstrumentRow(inst.rowId)}
                            className="text-xs text-red-400 hover:text-red-600 font-medium transition-colors">
                            Remove
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="md:col-span-2 relative">
                          <label className={labelClass}>Instrument Name</label>
                          <input
                            className={inputClass}
                            style={{ ...inputStyle, background: "white" }}
                            placeholder="Search by name, code, or brand..."
                            value={instrumentSearch[inst.rowId] ?? ""}
                            onChange={e => {
                              setInstrumentSearch(prev => ({ ...prev, [inst.rowId]: e.target.value }));
                              setInstrumentDropdownOpen(prev => ({ ...prev, [inst.rowId]: true }));
                              if (inst.instrument_id) {
                                updateInstrument(inst.rowId, "instrument_id", "");
                                updateInstrument(inst.rowId, "instrument_name", "");
                                updateInstrument(inst.rowId, "code_brand_model", "");
                              }
                            }}
                            onFocus={() => setInstrumentDropdownOpen(prev => ({ ...prev, [inst.rowId]: true }))}
                            onBlur={() => setTimeout(() => setInstrumentDropdownOpen(prev => ({ ...prev, [inst.rowId]: false })), 150)}
                          />
                          {isOpen && filtered.length > 0 && (
                            <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                              {filtered.slice(0, 50).map(option => (
                                <button key={option.id} type="button"
                                  className="w-full text-left px-4 py-2.5 hover:bg-blue-50 transition-colors border-b border-gray-50 last:border-0"
                                  onMouseDown={() => selectInstrumentOption(inst.rowId, option)}>
                                  <span className="text-sm font-medium text-gray-800">{option.instrument_name}</span>
                                  {option.type && <span className="text-xs text-gray-400 ml-1">({option.type})</span>}
                                  <div className="text-xs text-gray-400 mt-0.5">
                                    {[option.instrument_code, option.brand, option.model].filter(Boolean).join(" · ")}
                                  </div>
                                </button>
                              ))}
                              {filtered.length > 50 && (
                                <p className="px-4 py-2 text-xs text-gray-400 text-center">
                                  Showing 50 of {filtered.length} — type to narrow results
                                </p>
                              )}
                            </div>
                          )}
                          {isOpen && filtered.length === 0 && (instrumentSearch[inst.rowId] ?? "").length > 0 && (
                            <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg">
                              <p className="px-4 py-3 text-xs text-gray-400 text-center">No instruments found</p>
                            </div>
                          )}
                        </div>

                        <div>
                          <label className={labelClass}>Code / Brand / Model</label>
                          <input className={inputClass}
                            style={{ ...inputStyle, background: inst.instrument_id ? "#F3F4F6" : "white" }}
                            value={inst.code_brand_model}
                            readOnly={!!inst.instrument_id}
                            onChange={e => updateInstrument(inst.rowId, "code_brand_model", e.target.value)}
                            placeholder="Auto-filled on selection" />
                        </div>

                        <div>
                          <label className={labelClass}>Before Travel</label>
                          <div className="flex gap-3 mt-1">
                            {["Good Condition", "Not Good Condition"].map(option => (
                              <label key={option}
                                className="flex items-center gap-2.5 px-4 py-2.5 rounded-lg border cursor-pointer transition-all text-sm"
                                style={{
                                  borderColor: inst.before_travel === option ? "#1B2A6B" : "#E5E7EB",
                                  background: inst.before_travel === option ? "#EEF1FB" : "white",
                                  color: inst.before_travel === option ? "#1B2A6B" : "#6B7280",
                                  fontWeight: inst.before_travel === option ? 600 : 400,
                                }}>
                                <input type="radio" name={`before_travel_${inst.rowId}`} value={option}
                                  checked={inst.before_travel === option}
                                  onChange={() => updateInstrument(inst.rowId, "before_travel", option)}
                                  style={{ accentColor: "#1B2A6B" }} />
                                {option}
                              </label>
                            ))}
                          </div>
                        </div>

                        <div className="md:col-span-2">
                          <label className={labelClass}>Remarks</label>
                          <input className={inputClass} style={{ ...inputStyle, background: "white" }}
                            value={inst.remarks}
                            onChange={e => updateInstrument(inst.rowId, "remarks", e.target.value)}
                            placeholder="e.g. Handle with care" />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── TAB: Itinerary ──────────────────────────────────────────────── */}
          {activeTab === "itinerary" && (
            <div className="px-6 py-12 flex flex-col items-center justify-center text-center">
              <div className="w-12 h-12 rounded-full flex items-center justify-center mb-4" style={{ background: "#F4F6FB" }}>
                <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <p className="text-sm font-semibold text-gray-700">Itinerary is filled after testing</p>
              <p className="text-xs text-gray-400 mt-1 max-w-sm">
                The itinerary — including per diem, travel dates, and working hours — is completed during and after the dispatch. It will be available on the dispatch detail page.
              </p>
            </div>
          )}

          {/* ── TAB: Machines ───────────────────────────────────────────────── */}
          {activeTab === "machines" && (
            <div className="px-6 py-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-sm font-bold text-gray-800">Machines for Testing</h2>
                  <p className="text-xs text-gray-400 mt-0.5">List all machines to be tested in this dispatch.</p>
                </div>
                <button onClick={addMachine}
                  className="px-4 py-2 rounded-lg text-xs font-bold transition-all hover:opacity-90"
                  style={{ background: "#1B2A6B", color: "white" }}>
                  + Add Machine
                </button>
              </div>

              <div className="space-y-3">
                {machines.map((machine, idx) => (
                  <div key={machine.id} className="rounded-lg border border-gray-200 p-4" style={{ background: "#F8F9FB" }}>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Machine {idx + 1}</span>
                      {machines.length > 1 && (
                        <button onClick={() => removeMachine(machine.id)}
                          className="text-xs text-red-400 hover:text-red-600 font-medium transition-colors">
                          Remove
                        </button>
                      )}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div>
                        <label className={labelClass}>TAM No.</label>
                        <input className={inputClass} style={{ ...inputStyle, background: "white" }}
                          value={machine.tam_no} onChange={e => updateMachine(machine.id, "tam_no", e.target.value)}
                          placeholder="e.g. 2026-001" />
                      </div>
                      <div>
                        <label className={labelClass}>Machine</label>
                        <input className={inputClass} style={{ ...inputStyle, background: "white" }}
                          value={machine.machine} onChange={e => updateMachine(machine.id, "machine", e.target.value)}
                          placeholder="e.g. Rice Transplanter" />
                      </div>
                      <div>
                        <label className={labelClass}>Brand</label>
                        <input className={inputClass} style={{ ...inputStyle, background: "white" }}
                          value={machine.brand} onChange={e => updateMachine(machine.id, "brand", e.target.value)}
                          placeholder="e.g. Kubota" />
                      </div>
                      <div>
                        <label className={labelClass}>Model</label>
                        <input className={inputClass} style={{ ...inputStyle, background: "white" }}
                          value={machine.model} onChange={e => updateMachine(machine.id, "model", e.target.value)}
                          placeholder="e.g. SPU-68C" />
                      </div>
                      <div>
                        <label className={labelClass}>Serial No.</label>
                        <input className={inputClass} style={{ ...inputStyle, background: "white" }}
                          value={machine.serial_no} onChange={e => updateMachine(machine.id, "serial_no", e.target.value)}
                          placeholder="e.g. SN-20260001" />
                      </div>
                      <div>
                        <label className={labelClass}>Date of Test</label>
                        <input type="date" className={inputClass} style={{ ...inputStyle, background: "white" }}
                          value={machine.date_of_test} onChange={e => updateMachine(machine.id, "date_of_test", e.target.value)} />
                      </div>
                      <div>
                        <label className={labelClass}>Status</label>
                        <select className={inputClass} style={{ ...inputStyle, background: "white" }}
                          value={machine.status} onChange={e => updateMachine(machine.id, "status", e.target.value)}>
                          <option value="">— Not yet set —</option>
                          <option value="Passed">Passed</option>
                          <option value="Failed">Failed</option>
                        </select>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Footer */}
          <div className="px-6 py-4 border-t border-gray-100 flex items-center gap-4" style={{ background: "#F8F9FB" }}>
            <button onClick={saveDispatch} disabled={saving}
              className="px-6 py-2.5 rounded-lg text-sm font-bold transition-all hover:opacity-90 disabled:opacity-60"
              style={{ background: "#1B2A6B", color: "white" }}>
              {saving ? "Saving..." : "Save Changes"}
            </button>
            <button onClick={() => router.push(`/dispatches/${id}`)}
              className="px-6 py-2.5 rounded-lg text-sm font-medium transition-all"
              style={{ background: "white", color: "#6B7280", border: "1px solid #D1D5DB" }}>
              Cancel
            </button>
            <button onClick={deleteDispatch}
              className="px-6 py-2.5 rounded-lg text-sm font-bold transition-all hover:opacity-90 ml-auto"
              style={{ background: "#DC2626", color: "white" }}>
              Delete Dispatch
            </button>
            {msg && (
              <p className="text-sm font-medium"
                style={{ color: msgType === "success" ? "#16A34A" : "#DC2626" }}>
                {msg}
              </p>
            )}
          </div>

        </div>
      </div>
    </AppLayout>
  );
}
